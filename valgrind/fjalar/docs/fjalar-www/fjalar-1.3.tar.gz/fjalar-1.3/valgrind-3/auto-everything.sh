cd valgrind
./autogen.sh && ./configure --prefix=`pwd`/inst && make && make install
