
#include <fstream>
int main(void) {
        std::ofstream pippo("pluto");
        return 0;
};

