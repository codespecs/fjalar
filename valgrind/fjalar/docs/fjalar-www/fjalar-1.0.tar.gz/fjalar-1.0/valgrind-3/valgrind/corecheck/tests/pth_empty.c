// Does nothing, but linking it with -lpthread is enough to trigger an error
// that should be suppressed when it is run.

int main(void)
{
   return 0;
}
