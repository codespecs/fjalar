/* This file is part of hp2ps, a graph drawer for memory profiles.
   Copyright (C) 2002 The University Court of the University of Glasgow.
   This program is governed by the license contained in the file LICENSE.  */

#ifndef AXES_H
#define AXES_H

void Axes PROTO((void));

#endif /* AXES_H */
