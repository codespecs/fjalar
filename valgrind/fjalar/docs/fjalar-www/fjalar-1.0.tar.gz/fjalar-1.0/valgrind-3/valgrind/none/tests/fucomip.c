#include <stdio.h>

int main (int argc, char ** argv)
{
  float det = 625.f;

  if (det < 1)
  {
    printf ("erm, what ?\n");
  }
  return 0;
}
