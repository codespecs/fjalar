
/* general simple function to use as a template for assembly hacks */

void fooble ( int* a )
{
   a[0] = 33;
   a[1] = 44;
   a[2] = 55;
   a[3] = 66;
}
