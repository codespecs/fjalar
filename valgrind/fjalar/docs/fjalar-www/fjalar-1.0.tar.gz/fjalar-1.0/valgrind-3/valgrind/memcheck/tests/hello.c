
#include <stdio.h>

int main(void)
{
    fprintf(stderr, "Hello, world!\n");
    return 0;
}

