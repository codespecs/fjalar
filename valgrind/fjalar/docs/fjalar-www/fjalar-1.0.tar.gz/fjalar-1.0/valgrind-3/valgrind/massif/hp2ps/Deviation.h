/* This file is part of hp2ps, a graph drawer for memory profiles.
   Copyright (C) 2002 The University Court of the University of Glasgow.
   This program is governed by the license contained in the file LICENSE.  */

#ifndef DEVIATION_H
#define DEVIATION_H

void Deviation  PROTO((void));
void Identorder PROTO((int));

#endif /* DEVIATION_H */
