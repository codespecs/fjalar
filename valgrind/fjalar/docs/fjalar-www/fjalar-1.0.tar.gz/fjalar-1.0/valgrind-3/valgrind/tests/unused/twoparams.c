
/* general simple function to use as a template for assembly hacks */

int fooble ( int a, int b )
{
   return a - b;
}
