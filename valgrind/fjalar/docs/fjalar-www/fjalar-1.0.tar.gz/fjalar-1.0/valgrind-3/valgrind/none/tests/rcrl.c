#include <stdio.h>

  int main (void)  
  {
    double U = 
      ((double) 10586 / (double) 16119) + 
      ((double) 37190 / (double) 108363);
    printf ("x = %f\n", U);
  
    return 0;
  }

